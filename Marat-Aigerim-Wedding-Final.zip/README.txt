МАРАТ & АЙГЕРИМ — PHOTO + MUSIC INVITATION

GitHub Pages:
1. Репозиторийге төмөнкү файлдардын баарын жүктөңүз:
   index.html
   photo1.jpeg
   photo2.jpeg
   photo3.jpeg
   photo4.jpeg
   music.mp3
2. Settings → Pages → Deploy from branch → main / root.
3. Сайт ачылганда музыка баскычын басыңыз.

Музыка сиз жүктөгөн MP4 файлдан аудио катары бөлүнүп алынды.
